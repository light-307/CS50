// Buggy example for help50

int main(void)
{
    printf("hello, world\n")
}
