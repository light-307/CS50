// Poorly styled example for style50

#include <stdio.h>

int main(void)
    {
    printf("hello, world\n");
    }
